﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[posicao]))
                {
                    contaNum++;
                }

                posicao++;
            }

            MessageBox.Show("A frase tem " + contaNum + " números");
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            if (posicao > 0)
            {
                MessageBox.Show("1° caractere em branco está na posição " + posicao);
            }
            else
            {
                MessageBox.Show("Caractere em branco não encontrado");
            }
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"A frase tem {contaLetra} letras");
        }
    }
}
