﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividadeextra
{
    public partial class Form1 : Form
    {
        string[] diaSemana = {"Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"};

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxValores.Items.Clear();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            double[,] valorCompra = new double[7,5];
            double[] valorDia = new double[7];
            double totalGeral = 0;

            string entrada = "";

            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    entrada = Interaction.InputBox($"{diaSemana[i]} - Valor do produto {j + 1}: ");

                    if (entrada == "")
                        return;
                    else if (double.TryParse(entrada, out valorCompra[i, j]))
                    {
                        if (valorCompra[i, j] >= 0)
                        {
                            valorDia[i] += valorCompra[i, j];
                            totalGeral += valorCompra[i, j];
                        }
                        else
                        {
                            MessageBox.Show("O valor não pode ser negativo!");
                            j--;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                }
            }

            lstbxValores.Items.Clear();

            for (int i = 0;i < 7;i++)
            {
                lstbxValores.Items.Add($"{diaSemana[i]}: {valorDia[i]:F2}");
            }
            lstbxValores.Items.Add("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
            lstbxValores.Items.Add($"Total Geral: {totalGeral:F2}");
        }
    }
}