﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            double producao = double.Parse(txtProducao.Text);
            double salario = double.Parse(txtSalario.Text);
            double gratificacao = double.Parse(txtGratificacao.Text);

            int B = 0, C = 0, D = 0;

            if (producao >= 100)
                B = 1;
            if (producao >= 120)
                C = 1;
            if (producao >= 150)
                D = 1;

            double salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

            if (salarioBruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {

                }
                else
                {
                    salarioBruto = 7000;
                }
            }

            MessageBox.Show($"Salário Bruto = R$ {salarioBruto}");
        }

        private void txtNome_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Informe o nome do funcionário.");
                txtNome.Focus();
            }
        }

        private void txtMatricula_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMatricula.Text))
            {
                MessageBox.Show("Informe a matrícula do funcionário.");
                txtMatricula.Focus();
            }
        }

        private void txtProducao_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProducao.Text))
            {
                MessageBox.Show("Informe a produção.");
                txtProducao.Focus();
                return;
            }

            if (!double.TryParse(txtProducao.Text, out double producao))
            {
                MessageBox.Show("Produção deve ser um número válido.");
                txtProducao.Clear();
                txtProducao.Focus();
                return;
            }

            if (producao < 0)
            {
                MessageBox.Show("Produção não pode ser negativa.");
                txtProducao.Clear();
                txtProducao.Focus();
            }
        }

        private void txtSalario_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSalario.Text))
            {
                MessageBox.Show("Informe o salário.");
                txtSalario.Focus();
                return;
            }

            if (!double.TryParse(txtSalario.Text, out double salario))
            {
                MessageBox.Show("Salário deve ser um número válido.");
                txtSalario.Clear();
                txtSalario.Focus();
                return;
            }

            if (salario <= 0)
            {
                MessageBox.Show("Salário deve ser maior que zero.");
                txtSalario.Clear();
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtGratificacao.Text))
            {
                MessageBox.Show("Informe a gratificação (coloque 0 se não houver).");
                txtGratificacao.Focus();
                return;
            }

            if (!double.TryParse(txtGratificacao.Text, out double gratificacao))
            {
                MessageBox.Show("Gratificação deve ser um número válido.");
                txtGratificacao.Clear();
                txtGratificacao.Focus();
                return;
            }

            if (gratificacao < 0)
            {
                MessageBox.Show("Gratificação não pode ser negativa.");
                txtGratificacao.Clear();
                txtGratificacao.Focus();
            }
        }
    }
}
