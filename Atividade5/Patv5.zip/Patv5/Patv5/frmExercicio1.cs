﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {
            lblContador.Text = $"{rchtxtFrase.Text.Length}/100 caracteres";
        }

        private void btnEspacos_Click(object sender, EventArgs e)
        {
            int espacos = 0;
            string texto = rchtxtFrase.Text;

            for (int i = 0; i < texto.Length; i++)
            {
                if (texto[i] == ' ')
                {
                    espacos++;
                }
            }

            MessageBox.Show($"Total de espaços em branco: {espacos}");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int letraR = 0;
            int i = 0;
            string texto = rchtxtFrase.Text;
            
            while (i < texto.Length)
            {
                if (char.ToUpper(texto[i]) == 'R')
                {
                    letraR++;
                }
                i++;
            }

            MessageBox.Show($"Total de letra R: {letraR}");
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;
            int pares = 0;

            if (texto.Length >= 2)
            {
                int i = 0;

                do
                {
                    if (char.IsLetter(texto[i]) && char.ToLower(texto[i]) == char.ToLower(texto[i + 1]))
                    {
                        pares++;
                    }
                    i++;
                }
                while (i < texto.Length - 1);
            }

            MessageBox.Show($"Total de par de letras: {pares}");
        }
    }
}
