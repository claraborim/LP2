﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void txtFrase_TextChanged(object sender, EventArgs e)
        {
            lblContador.Text = $"{txtFrase.Text.Length}/50 caracteres";
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text.ToUpper().Replace(" ", "");

            int inicio = 0;
            int fim = frase.Length - 1;
            bool palindromo = true;

            while ( inicio < fim )
            {
                if (frase[inicio] != frase[fim])
                {
                    palindromo = false;
                    break;
                }

                inicio++;
                fim--;
            }

            if (palindromo)
                MessageBox.Show("É um palíndromo!");
            else
                MessageBox.Show("Não é um palíndromo.");
        }
    }
}
