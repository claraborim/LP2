﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patv5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnNumeroH_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumeroN.Text, out int numeroN))
            {
                if (numeroN > 0)
                {
                    double numeroH = 0;

                    for (int i = 1; i <= numeroN; i++)
                    {
                        numeroH += 1.0 / i;
                    }

                    MessageBox.Show($"Numero H = {numeroH:F2}");
                }
                else
                {
                    MessageBox.Show("Digite um número maior do que 0");
                }
            }
            else
            {
                MessageBox.Show("Digite um número inteiro");
            }
        }
    }
}
