﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {

        double valorA, valorB, valorC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();

            valorA = 0;
            valorB = 0;
            valorC = 0;
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((valorA < (valorB + valorC)) && (valorA > (Math.Abs(valorB - valorC)) &&
                (valorB < (valorA + valorC)) && (valorB > (Math.Abs(valorA - valorC)) &&
                (valorC < (valorA + valorB)) && (valorC > (Math.Abs(valorA - valorB))))))
            {
                if ((valorA == valorB) && (valorA == valorC))
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if (((valorA == valorB) && (valorA != valorC)) || ((valorA == valorC)) && (valorA != valorB))
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é triângulo");
            }
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProviderA.SetError(txtValorA, "");
                this.valorA = Convert.ToDouble(txtValorA.Text);
            }
            catch
            {
                errorProviderA.SetError(txtValorA, "Valor de A inválido");
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProviderB.SetError(txtValorB, "");
                this.valorB = Convert.ToDouble(txtValorB.Text);
            }
            catch
            {
                errorProviderB.SetError(txtValorB, "Valor de B inválido");
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProviderC.SetError(txtValorC, "");
                this.valorC = Convert.ToDouble(txtValorC.Text);
            }
            catch
            {
                errorProviderC.SetError(txtValorC, "Valor de C inválido");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
