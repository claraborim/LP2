﻿using Microsoft.VisualBasic;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string aux = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o n° {i + 1}", "Entrada de Dados");
                
                if (!int.TryParse(aux, out vetor[i])) {
                    MessageBox.Show("Número Inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            aux = "";

            foreach(int x in vetor)
                aux += x + "\n";

            MessageBox.Show(aux);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList
            {
                "Ana", "André", "Beatriz", "Camila", "João",
                "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
            };

            alunos.Remove("Otávio");

            string resultado = string.Join("\n", alunos.Cast<string>());

            MessageBox.Show(resultado);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string entrada = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    entrada = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i + 1}:", "Entrada de Notas");

                    if (entrada == "")
                        return;
                    else if (double.TryParse(entrada, out double valor))
                    {
                        if (valor >= 0 && valor <= 10)
                            notas[i, j] = valor;
                        else
                        {
                            MessageBox.Show("Valor inválido. Digite uma nota entre 0 e 10.");
                            j--;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido.");
                        j--;
                    }
                }
            }

            string resultado = "";
            double media = 0;

            for (int i = 0; i < 20; i++)
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                resultado += ($"Aluno {i + 1}: média {media:F1}\n");
            }

            MessageBox.Show(resultado);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 FrmExercicio4 = new frmExercicio4();
                FrmExercicio4.WindowState = FormWindowState.Normal;
                FrmExercicio4.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 FrmExercicio5 = new frmExercicio5();
                FrmExercicio5.WindowState = FormWindowState.Normal;
                FrmExercicio5.Show();
            }
        }
    }
}
