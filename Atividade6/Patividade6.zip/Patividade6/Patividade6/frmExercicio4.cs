﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade6
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            string entrada = "";

            for (int i = 0; i < 10; i++)
            {
                entrada = Interaction.InputBox($"Insira o {i + 1}º nome:", "Entrada de Nomes");

                if (entrada == "")
                    return;
                else if (string.IsNullOrWhiteSpace(entrada))
                {
                    MessageBox.Show("Nome inválido.");
                    i--;
                }
                else
                {
                    nomes[i] = entrada;
                    tamanhos[i] = entrada.Replace(" ", "").Length;
                }
            }

            lstbxNomes.Items.Clear();

            for (int i = 0; i < 10; i++)
            {
                lstbxNomes.Items.Add($"O nome {nomes[i]} tem {tamanhos[i]} caracteres.\n");
            }
        }
    }
}
