﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade6
{
    public partial class frmExercicio5 : Form
    {

        string[] gabarito = {"A", "B", "C", "D", "E", "E", "D", "C", "B", "A"};

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[4, 10];
            string entrada = "";

            for (int i = 0; i < 4;  i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    entrada = Interaction.InputBox($"ALUNO {i + 1} - resposta da {j + 1}ª questão:");
                    entrada = entrada.ToUpper();

                    if (entrada == "")
                        return;
                    else if (entrada != "A" && entrada != "B" && entrada != "C" && entrada != "D" && entrada != "E")
                    {
                        MessageBox.Show("Resposta inválida!");
                        j--;
                    }
                    else
                    {
                        respostas[i, j] = entrada;
                    }
                }
            }

            lstbxRespostas.Items.Clear();

            for (int i = 0; i < 4; i++)
            {
                lstbxRespostas.Items.Add($"-=-=- ALUNO {i + 1} -=-=-");

                for (int j = 0;j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                        lstbxRespostas.Items.Add($"Questão {j + 1}: Acertou! Era {gabarito[j]} e escolheu {respostas[i, j]}");
                    else
                        lstbxRespostas.Items.Add($"Questão {j + 1}: Errou! Era {gabarito[j]} e escolheu {respostas[i, j]}");
                }

                lstbxRespostas.Items.Add("");
            }
        }
    }
}
