﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {

        double num1, num2, resultado;

        private void txtNum2_Validated(object sender, EventArgs e)
        {

            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Número 2 inválido!");
                txtNum2.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Não é possível dividir por 0!");
                txtNum2.Focus();
            }
            else
            {
                resultado = num1 / num2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {

            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtNum1.Text, out num1))
            {
                MessageBox.Show("Número 1 inválido!");
                txtNum1.Focus();
            }
        }
    }
}
