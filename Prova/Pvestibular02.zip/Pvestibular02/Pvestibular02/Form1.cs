﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] cursoAno = new int[2, 5];
            int[] totalCurso = new int[2];
            int totalGeral = 0;

            string entrada = "";

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    entrada = Interaction.InputBox($"Total do curso {i + 1} do Ano {j + 1}: ");

                    if (entrada == "")
                        return;
                    else if (int.TryParse(entrada, out cursoAno[i, j]))
                    {
                        if (cursoAno[i, j] >= 0)
                        {
                            totalCurso[i] += cursoAno[i, j];
                            totalGeral += cursoAno[i, j];
                        }
                        else
                        {
                            MessageBox.Show("O valor não pode ser negativo.");
                            j--;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido.");
                        j--;
                    }
                }
            }
            lstbxResultado.Items.Clear();

            for (int i = 0; i < 2; i++)
            {
                lstbxResultado.Items.Add($"-=-=-=- Curso {i + 1} -=-=-=-");
                for (int j = 0;j < 5; j++)
                {
                    lstbxResultado.Items.Add($"Total Ano {j + 1}: {cursoAno[i, j]}");
                }
                lstbxResultado.Items.Add("");
                lstbxResultado.Items.Add($"Total Curso {i + 1}: {totalCurso[i]}");
                lstbxResultado.Items.Add("");
            }
            lstbxResultado.Items.Add("-=-=-=-=-=-=-=-=-=-=-=-");
            lstbxResultado.Items.Add($"Total Geral: {totalGeral}");
        }
    }
}
